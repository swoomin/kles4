// ✅ 지도 및 전역 변수 설정
var map;
var routeLayer;
var startMarker = null;
var endMarker = null;
var userMarker = null;
var routeLine = null;
var watchID = null; // GPS 추적 ID

// ✅ 지도 초기화 함수
function initMap() {
    console.log("📌 initMap 실행됨!");
    map = new Tmapv2.Map("map_div", {
        center: new Tmapv2.LatLng(36.3504119, 127.3845475), // 대전 시청 기준
        width: "100%",
        height: "600px",
        zoom: 14
    });
}

// ✅ 마커 추가 함수 (출발=파랑, 도착=빨강, 현재 위치=초록)
function addMarker(lat, lon, type) {
    if (!map) {
        console.error("❌ 지도(map)가 초기화되지 않았습니다.");
        return;
    }

    var markerIcon = "";
    var position = new Tmapv2.LatLng(lat, lon);

    if (type === "start") {
        markerIcon = "https://maps.google.com/mapfiles/ms/icons/blue-dot.png"; // 파란색 (출발지)
        if (startMarker) startMarker.setMap(null);
        startMarker = new Tmapv2.Marker({
            position: position,
            icon: markerIcon,
            map: map
        });

        // ✅ 출발지 마커 추가 후 해당 위치로 지도 이동
        map.setCenter(position);
        console.log(`📌 출발지 마커 추가됨 (${lat}, ${lon}) → 지도 이동 완료`);
    
    } else if (type === "end") {
        markerIcon = "https://maps.google.com/mapfiles/ms/icons/red-dot.png"; // 빨간색 (도착지)
        if (endMarker) endMarker.setMap(null);
        endMarker = new Tmapv2.Marker({
            position: position,
            icon: markerIcon,
            map: map
        });

        // ✅ 도착지 마커 추가 후 해당 위치로 지도 이동
        map.setCenter(position);
        console.log(`📌 도착지 마커 추가됨 (${lat}, ${lon}) → 지도 이동 완료`);
    
    } else if (type === "user") {
        markerIcon = "https://maps.google.com/mapfiles/ms/icons/green-dot.png"; // 초록색 (현재 위치)
        if (userMarker) userMarker.setMap(null);
        userMarker = new Tmapv2.Marker({
            position: position,
            icon: markerIcon,
            map: map
        });

        console.log(`📌 현재 위치 마커 추가됨 (${lat}, ${lon})`);
    }
}

// ✅ 현재 위치 가져오고 초록색 마커 추가
function getCurrentLocation() {
    if (!("geolocation" in navigator)) {
        alert("이 브라우저는 위치 정보를 지원하지 않습니다.");
        return;
    }

    // ✅ 기존 GPS 추적 중단 후 새로 시작
    if (watchID) {
        navigator.geolocation.clearWatch(watchID);
        watchID = null;
    }

    // ✅ 현재 위치를 즉시 가져오기
    navigator.geolocation.getCurrentPosition(function(position) {
        var userLat = position.coords.latitude;
        var userLon = position.coords.longitude;

        console.log(`📌 현재 위치 가져오기 성공: 위도=${userLat}, 경도=${userLon}`);

        // ✅ 현재 위치 마커 표시 (초록색)
        addMarker(userLat, userLon, "user");

        // ✅ 현재 위치를 주소로 변환하여 화면에 출력
        convertCoordinatesToAddress(userLat, userLon);

        // ✅ 지도 중심을 현재 위치로 이동 (줌 레벨 16)
        map.setCenter(new Tmapv2.LatLng(userLat, userLon));
        map.setZoom(16);

        // ✅ GPS 실시간 이동 추적 시작 (중복 방지)
        startNavigation();

    }, function(error) {
        console.error("❌ 현재 위치를 가져올 수 없습니다.", error);
        alert("❌ 현재 위치 정보를 가져올 수 없습니다.");
    }, { enableHighAccuracy: true });
}

// ✅ GPS 기반 실시간 위치 추적 (사용자 이동 감지)
function startNavigation() {
    if (!("geolocation" in navigator)) {
        alert("이 브라우저는 위치 정보를 지원하지 않습니다.");
        return;
    }

    // ✅ 기존 GPS 추적 중지 후 새로 시작
    if (watchID) {
        navigator.geolocation.clearWatch(watchID);
        watchID = null;
    }

    watchID = navigator.geolocation.watchPosition(function(position) {
        var userLat = position.coords.latitude;
        var userLon = position.coords.longitude;

        console.log(`📌 사용자 이동 감지: 위도=${userLat}, 경도=${userLon}`);

        // ✅ 현재 위치 마커 이동 (초록색 마커)
        addMarker(userLat, userLon, "user");

        // ✅ 지도 중심을 현재 위치로 이동
        map.setCenter(new Tmapv2.LatLng(userLat, userLon));

        // ✅ 현재 위치와 목적지 거리 확인
        checkArrival(userLat, userLon);

        // ✅ 사용자가 이동하면 남은 경로를 줄이기
        updateRemainingRoute(userLat, userLon);

    }, function(error) {
        console.error("❌ GPS 추적 오류:", error);
    }, { enableHighAccuracy: true, maximumAge: 1000, timeout: 5000 });
}

// ✅ 경로 업데이트 (사용자의 이동에 따라 경로 줄어들게 하기)
function updateRemainingRoute(userLat, userLon) {
    if (!routeLine) return;

    var newPath = [];
    var path = routeLine.getPath(); // 현재 경로 가져오기

    for (var i = 0; i < path.length; i++) {
        var point = path[i];
        var distance = getDistance(userLat, userLon, point.lat(), point.lng());

        if (distance > 10) {  // 10m 이상 떨어진 지점만 유지
            newPath.push(point);
        }
    }

    if (newPath.length > 0) {
        routeLine.setPath(newPath); // ✅ 남은 경로 업데이트
    } else {
        routeLine.setMap(null); // ✅ 경로 종료 시 지도에서 삭제
    }
}

// ✅ 목적지 도착 여부 확인
function checkArrival(userLat, userLon) {
    var destinationLat = endMarker.getPosition().lat();
    var destinationLon = endMarker.getPosition().lng();

    var distance = getDistance(userLat, userLon, destinationLat, destinationLon);

    console.log(`📌 목적지까지 거리: ${distance}m`);

    if (distance < 10) {  // 10m 이내 도착 시 알림
        alert("🎉 목적지에 도착했습니다!");
        navigator.geolocation.clearWatch(watchID); // ✅ GPS 추적 종료
        watchID = null;
    }
}

// ✅ 두 좌표 간 거리 계산 함수 (Haversine Formula 사용)
function getDistance(lat1, lon1, lat2, lon2) {
    function toRad(value) {
        return value * Math.PI / 180;
    }

    var R = 6371e3; // 지구 반지름 (미터)
    var φ1 = toRad(lat1);
    var φ2 = toRad(lat2);
    var Δφ = toRad(lat2 - lat1);
    var Δλ = toRad(lon2 - lon1);

    var a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);

    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // 미터 단위 거리 반환
}

// ✅ 위도/경도를 주소로 변환하여 화면에 표시하는 함수
function convertCoordinatesToAddress(lat, lon) {
    var apiUrl = `https://apis.openapi.sk.com/tmap/geo/reversegeocoding?version=1&format=json&coordType=WGS84GEO&lat=${lat}&lon=${lon}&appKey=${authKey}`;

    $.ajax({
        method: "GET",
        url: apiUrl,
        dataType: "json",
        success: function(response) {
            if (response.addressInfo) {
                var userAddress = response.addressInfo.fullAddress;
                console.log(`📌 변환된 주소: ${userAddress}`);

                // ✅ 화면에 주소 표시
                document.getElementById("location-info").innerHTML = `📍 현재 위치: ${userAddress}`;
            } else {
                console.warn("❌ 주소 변환 실패");
                document.getElementById("location-info").innerHTML = `📍 현재 위치: 주소를 찾을 수 없습니다.`;
            }
        },
        error: function(xhr, status, error) {
            console.error("❌ 주소 변환 오류:", error);
            document.getElementById("location-info").innerHTML = `📍 현재 위치: 주소 변환 오류`;
        }
    });
}

// ✅ 출발지/도착지 주소 → 좌표 변환 함수
function getCoordinates(address, type) {
    if (!address || address.trim() === "") {
        alert("⚠️ 주소를 입력해주세요.");
        return;
    }

    var encodedAddress = encodeURIComponent(address.trim());
    var apiUrl = `https://apis.openapi.sk.com/tmap/geo/fullAddrGeo?version=1.0&format=json&coordType=WGS84GEO&fullAddr=${encodedAddress}&appKey=${authKey}`;

    $.ajax({
        method: "GET",
        url: apiUrl,
        dataType: "json",
        success: function(response) {
            if (response.coordinateInfo && response.coordinateInfo.coordinate.length > 0) {
                var lat = parseFloat(response.coordinateInfo.coordinate[0].lat);
                var lon = parseFloat(response.coordinateInfo.coordinate[0].lon);
                console.log(`✅ 주소 변환 성공: ${address} → 위도: ${lat}, 경도: ${lon}`);
                addMarker(lat, lon, type); // ✅ 입력 즉시 마커 추가
            } else {
                alert("⚠️ 해당 주소를 찾을 수 없습니다.");
            }
        },
        error: function(xhr, status, error) {
            console.error("❌ 주소 변환 오류:", error);
            alert("❌ 주소 변환 중 오류가 발생했습니다.");
        }
    });
}

// ✅ 출발지 또는 도착지 입력 후 자동으로 지도 이동
function searchAddress(type) {
    console.log(`📌 searchAddress() 실행됨, type: ${type}`);

    var inputElement = document.getElementById(type + "Input");
    if (!inputElement) {
        console.error(`❌ 입력창을 찾을 수 없습니다. type: ${type}`);
        alert("입력창이 존재하지 않습니다. 다시 확인해주세요.");
        return;
    }

    var address = inputElement.value.trim();
    if (!address) {
        alert("⚠️ 주소를 입력해주세요.");
        return;
    }

    getCoordinates(address, type);
}

// ✅ 길찾기 실행 함수
function searchRoute() {
    var startInput = document.getElementById("startInput").value.trim();
    var endInput = document.getElementById("endInput").value.trim();

    if (!startInput || !endInput) {
        alert("⚠️ 출발지와 도착지를 입력해주세요.");
        return;
    }

    console.log(`📌 경로 검색 실행: 출발지=${startInput}, 도착지=${endInput}`);

    getCoordinates(startInput, "start");
    getCoordinates(endInput, "end");

    findPathOnMap();
}

// ✅ 출발지~도착지 경로를 지도에 그리는 함수
function findPathOnMap() {
    var apiUrl = `https://apis.openapi.sk.com/tmap/routes/pedestrian?version=1&format=json&appKey=${authKey}`;

    // ✅ 출발지 마커가 없을 경우 방어 코드 추가
    if (!startMarker || !endMarker) {
        alert("⚠️ 출발지와 도착지를 먼저 설정해주세요.");
        return;
    }

    $.ajax({
        method: "POST",
        url: apiUrl,
        data: JSON.stringify({
            startX: startMarker.getPosition().lng(),
            startY: startMarker.getPosition().lat(),
            endX: endMarker.getPosition().lng(),
            endY: endMarker.getPosition().lat(),
            reqCoordType: "WGS84GEO",
            resCoordType: "WGS84GEO",
            startName: "출발지",
            endName: "도착지"
        }),
        contentType: "application/json",
        success: function(response) {
            var path = [];
            var features = response.features;

            for (var i = 0; i < features.length; i++) {
                var geometry = features[i].geometry;

                if (geometry.type === "LineString") {
                    for (var j = 0; j < geometry.coordinates.length; j++) {
                        var lonlat = new Tmapv2.LatLng(geometry.coordinates[j][1], geometry.coordinates[j][0]);
                        path.push(lonlat);
                    }
                }
            }

            // ✅ 기존 경로 삭제 후 다시 그림
            if (routeLine) {
                routeLine.setMap(null);
            }

            // ✅ 경로를 지도에 표시
            routeLine = new Tmapv2.Polyline({
                path: path,
                strokeColor: "#FF0000", // 빨간색 경로
                strokeWeight: 6,
                map: map
            });

            // ✅ 길찾기 시작 시 **출발지 중심으로 지도 이동**
            map.setCenter(startMarker.getPosition());

            console.log("✅ 경로 탐색 성공! 출발지 기준 지도 이동 완료");

            // ✅ GPS 네비게이션 시작
            startNavigation();
        },
        error: function(xhr, status, error) {
            console.error("❌ 경로 탐색 오류:", error);
            alert("경로 탐색 중 오류가 발생했습니다.");
        }
    });
}

// ✅ GPS 기반 네비게이션 (실제 이동 반영)
function startNavigation() {
    if (watchID) {
        navigator.geolocation.clearWatch(watchID);
    }

    watchID = navigator.geolocation.watchPosition(function(position) {
        var userLat = position.coords.latitude;
        var userLon = position.coords.longitude;

        addMarker(userLat, userLon, "user"); // 사용자 이동 반영
    }, function(error) {
        console.error("❌ GPS 추적 오류:", error);
    }, { enableHighAccuracy: true });
}


// ✅ 길찾기 취소 함수
function cancelRoute() {
    console.log("🚫 길찾기 취소!");

    // ✅ 경로(폴리라인) 제거
    if (routeLine) {
        routeLine.setMap(null);
        routeLine = null;
    }

    // ✅ 출발지, 도착지 마커 제거
    if (startMarker) {
        startMarker.setMap(null);
        startMarker = null;
    }
    if (endMarker) {
        endMarker.setMap(null);
        endMarker = null;
    }

    // ✅ 네비게이션 정지 (GPS 추적 해제)
    if (watchID) {
        navigator.geolocation.clearWatch(watchID);
        watchID = null;
    }

    alert("🚫 길찾기가 취소되었습니다.");
}